

'use server';

import prisma from '@/lib/prisma';
import { Project, Volunteer, Donation, User, Settings, Category, SocialLink, ProjectStatus, DonationType, Role, VolunteerStatus } from './types';
import { defaultSettings } from './default-settings';

// Categories
export async function getCategories(): Promise<Category[]> {
    return await prisma.category.findMany();
}

export async function createCategory(name: string): Promise<Category> {
    return await prisma.category.create({
        data: { name }
    });
}

export async function updateCategory(id: string, name: string): Promise<Category> {
    return await prisma.category.update({
        where: { id },
        data: { name },
    });
}

export async function deleteCategory(id: string): Promise<void> {
    await prisma.project.updateMany({
        where: { categoryId: id },
        data: { categoryId: null }
    });
    await prisma.donation.updateMany({
        where: { categoryId: id },
        data: { categoryId: null }
    });
    await prisma.category.delete({ where: { id } });
}

// Projects
export async function getProjects(): Promise<Project[]> {
    const projects = await prisma.project.findMany({ include: { category: true } });
    return projects.map(p => ({ 
        ...p, 
        status: p.status as ProjectStatus,
        category: p.category?.name || 'Uncategorized',
        details: Array.isArray(p.details) ? (p.details as unknown as string[]) : [],
    }));
}

export async function getProjectById(id: string): Promise<Project | null> {
    const project = await prisma.project.findUnique({ where: { id }, include: { category: true } });
    if (!project) return null;
    return { 
        ...project, 
        status: project.status as ProjectStatus,
        category: project.category?.name || 'Uncategorized',
        details: Array.isArray(project.details) ? (project.details as unknown as string[]) : [],
    };
}

export async function createProject(project: Omit<Project, 'id' | 'peopleHelped' | 'category'> & { category: string, imageUrl?: string }) {
    return await prisma.project.create({
        data: {
            title: project.title,
            description: project.description,
            imageUrl: project.imageUrl,
            details: project.details,
            status: project.status,
            startDate: project.startDate,
            peopleHelped: 0,
            category: {
                connectOrCreate: {
                    where: { name: project.category },
                    create: { name: project.category }
                }
            }
        }
    });
}

export async function updateProject(id: string, data: Partial<Omit<Project, 'id' | 'category'>> & { category?: string, imageUrl?: string }) {
    const { category, categoryId, ...projectData } = data;
    
    return await prisma.project.update({
        where: { id },
        data: {
            ...projectData,
            ...(category ? {
                category: {
                    connectOrCreate: {
                        where: { name: category },
                        create: { name: category }
                    }
                }
            } : (categoryId !== undefined ? { categoryId } : {})),
        },
    });
}

export async function deleteProject(id: string): Promise<void> {
    await prisma.donation.updateMany({
        where: { projectId: id },
        data: { projectId: null }
    });
    await prisma.project.delete({ where: { id } });
}

// Volunteers
export async function getVolunteers(): Promise<Volunteer[]> {
    const volunteers = await prisma.volunteer.findMany();
    return volunteers.map(v => ({
        ...v,
        status: v.status as VolunteerStatus,
        interests: Array.isArray(v.interests) ? (v.interests as unknown as string[]) : [],
        availability: Array.isArray(v.availability) ? (v.availability as unknown as string[]) : [],
    }))
}

export async function getVolunteerByEmail(email: string): Promise<Volunteer | null> {
    const v = await prisma.volunteer.findUnique({ where: { email } });
    if (!v) return null;
    return {
        ...v,
        status: v.status as VolunteerStatus,
        interests: Array.isArray(v.interests) ? (v.interests as unknown as string[]) : [],
        availability: Array.isArray(v.availability) ? (v.availability as unknown as string[]) : [],
    };
}

export async function getVolunteerByPhone(phone: string): Promise<Volunteer | null> {
    const v = await prisma.volunteer.findFirst({ where: { phone } });
    if (!v) return null;
    return {
        ...v,
        status: v.status as VolunteerStatus,
        interests: Array.isArray(v.interests) ? (v.interests as unknown as string[]) : [],
        availability: Array.isArray(v.availability) ? (v.availability as unknown as string[]) : [],
    };
}


export async function createVolunteer(volunteer: Omit<Volunteer, 'id' | 'status' | 'signupDate'>) {
    const existingByEmail = await getVolunteerByEmail(volunteer.email);
    if (existingByEmail) {
        throw new Error('A volunteer with this email already exists.');
    }

    if (volunteer.phone) {
        const existingByPhone = await getVolunteerByPhone(volunteer.phone);
        if (existingByPhone) {
            throw new Error('A volunteer with this phone number already exists.');
        }
    }

    return await prisma.volunteer.create({
        data: {
            ...volunteer,
            status: 'Pending',
            signupDate: new Date(),
        }
    });
}


export async function updateVolunteer(id: string, data: Partial<Omit<Volunteer, 'id'>>) {
    return await prisma.volunteer.update({
        where: { id },
        data: data,
    });
}

export async function deleteVolunteer(id: string): Promise<void> {
    await prisma.volunteer.delete({ where: { id } });
}

// Users
export async function getUsers(): Promise<User[]> {
    return (await prisma.user.findMany()).map(u => ({ ...u, role: u.role as Role, password: u.password || undefined }));
}

export async function getUserByEmail(email: string): Promise<User | null> {
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) return null;
    return { ...user, role: user.role as Role, password: user.password || undefined };
}

export async function getUserById(id: string): Promise<User | null> {
    const user = await prisma.user.findUnique({ where: { id } });
    if (!user) return null;
    return { ...user, role: user.role as Role, password: user.password || undefined };
}

export async function createUser(user: Omit<User, 'id' | 'joinDate' | 'role'>) {
    if (!user.password) {
        throw new Error("Password is required for new user");
    }
    return await prisma.user.create({
        data: {
            ...user,
            password: user.password,
            role: 'ADMIN',
        }
    });
}

export async function updateUser(id: string, data: Partial<Omit<User, 'id'>>) {
    const { password, ...otherData } = data;
    return await prisma.user.update({
        where: { id },
        data: {
            ...otherData,
            ...(password ? { password } : {}),
        },
    });
}

export async function deleteUser(id: string): Promise<void> {
    await prisma.user.delete({ where: { id } });
}
  
// Donations
export async function getDonations(): Promise<Donation[]> {
  const donations = await prisma.donation.findMany({ include: { project: { include: { category: true } }, category: true } });
  return donations.map(d => ({
    ...d,
    type: d.type as DonationType,
    amount: typeof d.amount === 'number' ? d.amount : parseFloat(d.amount as any),
    project: d.project ? { ...d.project, details: [], status: d.project.status as ProjectStatus, category: d.project.category?.name || 'Uncategorized' } : null,
  }));
}

export async function createDonation(donation: Omit<Donation, 'id' | 'date'>) {
    const { projectId, categoryId, ...donationData } = donation as any;

    return await prisma.donation.create({
        data: {
            ...donationData,
            ...(projectId && { project: { connect: { id: projectId } } }),
            ...(categoryId && { category: { connect: { id: categoryId } } }),
        }
    });
}

// Settings
export async function getSettings(): Promise<Settings> {
    const dbSettings = await prisma.settings.findFirst();
    
    if (!dbSettings) {
        return defaultSettings;
    }

    return {
        id: dbSettings.id,
        appName: dbSettings.appName || defaultSettings.appName,
        logo: dbSettings.logo || defaultSettings.logo,
        logoType: (dbSettings.logoType as 'icon' | 'image') || defaultSettings.logoType,
        volunteerIcon: dbSettings.volunteerIcon || defaultSettings.volunteerIcon,
        heroTitle: dbSettings.heroTitle || defaultSettings.heroTitle,
        heroDescription: dbSettings.heroDescription || defaultSettings.heroDescription,
        heroImage: dbSettings.heroImage,
        heroImage1: dbSettings.heroImage1,
        heroImage2: dbSettings.heroImage2,
        heroImage3: dbSettings.heroImage3,
        heroImage4: dbSettings.heroImage4,
        missionIntroTitle: dbSettings.missionIntroTitle || defaultSettings.missionIntroTitle,
        missionIntroDescription: dbSettings.missionIntroDescription || defaultSettings.missionIntroDescription,
        missionImage: dbSettings.missionImage,
        missionTitle: dbSettings.missionTitle || defaultSettings.missionTitle,
        missionDescription: dbSettings.missionDescription || defaultSettings.missionDescription,
        visionTitle: dbSettings.visionTitle || defaultSettings.visionTitle,
        visionDescription: dbSettings.visionDescription || defaultSettings.visionDescription,
        valuesTitle: dbSettings.valuesTitle || defaultSettings.valuesTitle,
        valuesDescription: dbSettings.valuesDescription || defaultSettings.valuesDescription,
        volunteerIntroTitle: dbSettings.volunteerIntroTitle || defaultSettings.volunteerIntroTitle,
        volunteerIntroDescription1: dbSettings.volunteerIntroDescription1 || defaultSettings.volunteerIntroDescription1,
        volunteerIntroDescription2: dbSettings.volunteerIntroDescription2 || defaultSettings.volunteerIntroDescription2,
        socialLinks: [
            { icon: 'Twitter', href: dbSettings.socialLinksTwitter || '#' },
            { icon: 'Facebook', href: dbSettings.socialLinksFacebook || '#' },
            { icon: 'Instagram', href: dbSettings.socialLinksInstagram || '#' },
            { icon: 'Youtube', href: dbSettings.socialLinksYoutube || '#' },
            { icon: 'Telegram', href: dbSettings.socialLinksTelegram || '#' },
            { icon: 'WhatsApp', href: dbSettings.socialLinksWhatsApp || '#' },
            { icon: 'Email', href: dbSettings.socialLinksEmail || '#' },
            { icon: 'Linkedin', href: dbSettings.socialLinksLinkedin || '#' },
            { icon: 'TikTok', href: dbSettings.socialLinksTikTok || '#' },
        ].filter(link => link.href && link.href !== '#') as SocialLink[],
    };
}


export async function updateSettings(settings: Partial<Settings>) {
    const currentSettings = await prisma.settings.findFirst();

    const dataToUpdate = {
        appName: settings.appName,
        logo: settings.logo,
        logoType: settings.logoType,
        volunteerIcon: settings.volunteerIcon,
        heroTitle: settings.heroTitle,
        heroDescription: settings.heroDescription,
        heroImage: settings.heroImage,
        heroImage1: settings.heroImage1,
        heroImage2: settings.heroImage2,
        heroImage3: settings.heroImage3,
        heroImage4: settings.heroImage4,
        missionIntroTitle: settings.missionIntroTitle,
        missionIntroDescription: settings.missionIntroDescription,
        missionImage: settings.missionImage,
        missionTitle: settings.missionTitle,
        missionDescription: settings.missionDescription,
        visionTitle: settings.visionTitle,
        visionDescription: settings.visionDescription,
        valuesTitle: settings.valuesTitle,
        valuesDescription: settings.valuesDescription,
        volunteerIntroTitle: settings.volunteerIntroTitle,
        volunteerIntroDescription1: settings.volunteerIntroDescription1,
        volunteerIntroDescription2: settings.volunteerIntroDescription2,
        socialLinksTwitter: settings.socialLinks?.find(s => s.icon === 'Twitter')?.href,
        socialLinksFacebook: settings.socialLinks?.find(s => s.icon === 'Facebook')?.href,
        socialLinksInstagram: settings.socialLinks?.find(s => s.icon === 'Instagram')?.href,
        socialLinksYoutube: settings.socialLinks?.find(s => s.icon === 'YouTube')?.href,
        socialLinksTelegram: settings.socialLinks?.find(s => s.icon === 'Telegram')?.href,
        socialLinksWhatsApp: settings.socialLinks?.find(s => s.icon === 'WhatsApp')?.href,
        socialLinksEmail: settings.socialLinks?.find(s => s.icon === 'Mail')?.href,
        socialLinksLinkedin: settings.socialLinks?.find(s => s.icon === 'Linkedin')?.href,
        socialLinksTikTok: settings.socialLinks?.find(s => s.icon === 'TikTok')?.href,
    };


    if (currentSettings) {
        return await prisma.settings.update({
            where: { id: currentSettings.id },
            data: dataToUpdate
        });
    } else {
        return await prisma.settings.create({
            data: {
                ...dataToUpdate,
                appName: settings.appName || defaultSettings.appName || 'Benevolence Hub',
            }
        });
    }
}
