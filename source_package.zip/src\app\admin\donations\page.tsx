

import * as React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { MoreHorizontal } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { getProjects, getDonations, getCategories } from '@/lib/db';
import { format } from 'date-fns';
import { DonationFilter } from './_components/donation-filter';
import { PaginationControls } from '@/components/ui/pagination';
import { Donation, Project } from '@/lib/types';

export const dynamic = 'force-dynamic';

const ITEMS_PER_PAGE = 7;

export default async function AdminDonationsPage({ searchParams }: { searchParams: { [key: string]: string | string[] | undefined }}) {
    // Ensure searchParams is properly typed and awaited
    const params = await searchParams;
    const page = Number(params?.page || '1');
    const skip = (page - 1) * ITEMS_PER_PAGE;
    
    const typeFilter = params?.type as string | undefined;
    const projectFilter = params?.project as string | undefined;

    const allProjects = await getProjects();
    const allDonations = await getDonations();

    const projectNames = ['General Fund', ...allProjects.map(p => p.title)];

    const filteredDonations = allDonations.filter(donation => {
        const donationProject = allProjects.find(p => p.id === donation.projectId);
        if (donationProject) {
            (donation as any).project = donationProject;
        }

        const typeMatch = !typeFilter || typeFilter === 'all' || 
            (typeFilter === 'One-time' && donation.type === 'ONE_TIME') ||
            (typeFilter === 'Monthly' && donation.type === 'MONTHLY');
        
        const projectMatch = !projectFilter || projectFilter === 'all' || 
            (projectFilter === 'General Fund' && !donation.projectId) ||
            (donationProject && donationProject.title === projectFilter);
        
        return typeMatch && projectMatch;
    });

    const donations = filteredDonations
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .slice(skip, skip + ITEMS_PER_PAGE);

    const totalDonations = filteredDonations.length;
    const totalPages = Math.ceil(totalDonations / ITEMS_PER_PAGE);

  return (
    <div className="flex flex-col h-full gap-6 p-4 sm:p-6 w-full max-w-full overflow-x-auto">
        <Card className="w-full">
            <CardContent className="p-4 grid sm:grid-cols-2 gap-4">
                <DonationFilter projectNames={projectNames} />
            </CardContent>
        </Card>

         <div className="rounded-lg border flex-1 flex flex-col w-full overflow-x-auto">
            <div className="relative flex-grow w-full">
                <ScrollArea className="absolute inset-0 w-full">
                    <Table>
                        <TableHeader>
                        <TableRow>
                            <TableHead>Donor Name</TableHead>
                            <TableHead>Amount</TableHead>
                            <TableHead className='hidden sm:table-cell'>Type</TableHead>
                            <TableHead className='hidden md:table-cell'>Project</TableHead>
                            <TableHead className='hidden lg:table-cell'>Date</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                        </TableHeader>
                        <TableBody>
                        {donations.map((donation) => {
                            return (
                                <TableRow key={donation.id}>
                                <TableCell className="font-medium">{donation.donorName}</TableCell>
                                <TableCell>${(donation.amount as any).toFixed(2)}</TableCell>
                                <TableCell className='hidden sm:table-cell'>
                                    <Badge variant={donation.type === 'MONTHLY' ? 'outline' : 'default'}>
                                        {donation.type === 'ONE_TIME' ? 'One-time' : 'Monthly'}
                                    </Badge>
                                </TableCell>
                                <TableCell className='hidden md:table-cell'>{(donation as any).project?.title || 'General Fund'}</TableCell>
                                <TableCell className='hidden lg:table-cell'>{format(new Date(donation.date), 'yyyy-MM-dd')}</TableCell>
                                <TableCell className="text-right">
                                    <Button variant="ghost" size="icon">
                                        <MoreHorizontal className="h-4 w-4" />
                                    </Button>
                                </TableCell>
                                </TableRow>
                            );
                        })}
                        </TableBody>
                    </Table>
                </ScrollArea>
            </div>
             {totalPages > 1 && (
                <div className="p-4 border-t">
                    <PaginationControls
                        currentPage={page}
                        totalPages={totalPages}
                    />
                </div>
             )}
        </div>
    </div>
  );
}
